from jhansi.token import TokenType
from jhansi.lexer import Lexer
import pytest

def test_empty_source() -> None:
    src = "   "
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 1
    assert token[0].kind == TokenType.EOF

def test_token_is_int() -> None:
    src = "345"
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 2
    assert token[0].kind == TokenType.INT_LIT
    assert token[0].value == 345

def test_token_is_bool() -> None:
    src = "bool"
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 2
    assert token[0].kind == TokenType.BOOL
    assert token[0].value == "bool"


def test_token_is_bool_true() -> None:
    src = "true"
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 2
    assert token[0].kind == TokenType.TRUE
    assert token[0].value == "true"

def test_token_is_bool_false() -> None:
    src = "false"
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 2
    assert token[0].kind == TokenType.FALSE
    assert token[0].value == "false"

def test_token_is_basic_char_literal() -> None:
    src = "'a'"
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 2
    assert token[0].kind == TokenType.CHAR_LIT
    assert token[0].value == 'a'

def test_token_is_escape_char_literal() -> None:
    src = "'\0'"
    token = Lexer(src).tokenize()
    assert token is not None
    assert len(token) == 2
    assert token[0].kind == TokenType.CHAR_LIT
    assert token[0].value == '\0'
    
def test_invalid_character_raises_syntax_error() -> None:
    src = "123 $ 456"
    with pytest.raises(SyntaxError, match=r"unknown character: \$"):
        Lexer(src).tokenize()

def test_invalid_character_at_start() -> None:
    src = "$123456"
    with pytest.raises(SyntaxError, match=r"unknown character: \$"):
        Lexer(src).tokenize()

def test_arithmetic_op_success() -> None:
    src = "+-*/" # Arithmetic operations
    tokens = Lexer(src).tokenize()
    assert tokens is not None
    assert len(tokens) == 5
    assert tokens[0].kind == TokenType.PLUS
    assert tokens[1].kind == TokenType.MINUS
    assert tokens[2].kind == TokenType.STAR
    assert tokens[3].kind == TokenType.SLASH

def test_expression_wrapper() -> None:
    src = "()"
    tokens = Lexer(src).tokenize()
    assert tokens is not None
    assert len(tokens) == 3
    assert tokens[0].kind == TokenType.LPAREN
    assert tokens[1].kind == TokenType.RPAREN

def test_unary() -> None:
    src = "-3" # Arithmetic operations
    tokens = Lexer(src).tokenize()
    assert tokens is not None
    assert len(tokens) == 3
    assert tokens[0].kind == TokenType.MINUS
    assert tokens[1].kind == TokenType.INT_LIT
    assert tokens[2].kind == TokenType.EOF

def test_identifier() -> None:
    src = "x=3" # Variable assignments
    tokens = Lexer(src).tokenize()
    assert tokens is not None
    assert len(tokens) == 4
    assert tokens[0].kind == TokenType.IDENT
    assert tokens[1].kind == TokenType.EQUAL
    assert tokens[2].kind == TokenType.INT_LIT
    assert tokens[3].kind == TokenType.EOF
    
def test_variable_declaration_with_no_assignment() -> None:
    src = "var x int;" # Variable assignments
    tokens = Lexer(src).tokenize()
    assert tokens is not None
    assert len(tokens) == 5
    assert tokens[0].kind == TokenType.VAR
    assert tokens[1].kind == TokenType.IDENT
    assert tokens[2].kind == TokenType.INT
    assert tokens[3].kind == TokenType.SEMI
    assert tokens[4].kind == TokenType.EOF

def test_variable_declaration_with_assignment() -> None:
    src = "var x int = 10;" # Variable assignments
    tokens = Lexer(src).tokenize()
    assert tokens is not None
    assert len(tokens) == 7
    assert tokens[0].kind == TokenType.VAR
    assert tokens[1].kind == TokenType.IDENT
    assert tokens[2].kind == TokenType.INT
    assert tokens[3].kind == TokenType.EQUAL
    assert tokens[4].kind == TokenType.INT_LIT
    assert tokens[5].kind == TokenType.SEMI
    assert tokens[6].kind == TokenType.EOF
